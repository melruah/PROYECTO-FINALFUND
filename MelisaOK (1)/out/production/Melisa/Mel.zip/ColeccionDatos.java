import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;

import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

public class ColeccionDatos {
    private String fileName;
    private ArrayList<Dato> coleccionDatos;
  
    public ColeccionDatos(String fileName) {
      this.fileName = fileName;
    }

    public ArrayList<Dato> getCsv(){
      ArrayList<Dato> csv = new ArrayList<Dato>();
      try {
        File myObj = new File(this.fileName);
        Scanner myReader = new Scanner(myObj);
        myReader.nextLine(); // Saltar headers
        while (myReader.hasNextLine()) {
          String info = myReader.nextLine().replaceAll("\"","").replaceAll(",,",",-1,");
          if (info.endsWith(",")){
            info += "-1";
          }
          String[] data = info.split(",");
          String station = data[0];
          String name = data[1] + "," + data[2];          
          String date = data[3];
          Double prcp = Double.parseDouble(data[4]);
          Double tavg = Double.parseDouble(data[5]);
          Double tmax = Double.parseDouble(data[6]);
          Double tmin = Double.parseDouble(data[7]);
          csv.add(new Dato(station, name, date, prcp, tavg, tmax, tmin));
        }
        myReader.close();
      } catch (FileNotFoundException e) {
        System.out.println("An error occurred.");
        e.printStackTrace();
      }

      return csv;
    }

    public void setColeccionDatos() {
      coleccionDatos = this.getCsv();
    }

    public Double avgTmax(){
      Double avgTmax = 0.0D;
      int count = 0;
      for (int i=0;i<coleccionDatos.size();i++) {
        Double tMax = coleccionDatos.get(i).getTmax();
        if(tMax != -1){
          avgTmax += tMax;
          count++;
        }
      }
      return avgTmax/count;
    }

    public Double sumTmin(){
      Double tmin = 0.0D;
      for (int i=0;i<coleccionDatos.size();i++) {
        Double tminDato = coleccionDatos.get(i).getTmin();
        if(tmin != -1){
          tmin += tminDato;
        }
      }
      return tmin;
    }

    public Double maxTavg(){
      Double tmax = 0.0D;
      for (int i=0;i<coleccionDatos.size();i++) {
        Double tavg  = coleccionDatos.get(i).getTavg();
        if (tavg > tmax){
          tmax = tavg;
        }
      }
      return tmax;
    }

    public Double minTavg(){
      Double tmin = 0.0D;
      for (int i=0;i<coleccionDatos.size();i++) {
        Double tavg  = coleccionDatos.get(i).getTavg();
        if (tavg < tmin){
          tmin = tavg;
        }
      }
      return tmin;
    }
}